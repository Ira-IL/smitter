export interface WeatherData {
    sunset: number;
    country: string;
    city: string;
    temp: number;
    pressure: number;
}