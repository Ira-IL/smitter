export const base_url = 'https://api.openweathermap.org/data/2.5/weather';
export const api_key = 'd177298e9759d3c6f1e68095b864e2f2'