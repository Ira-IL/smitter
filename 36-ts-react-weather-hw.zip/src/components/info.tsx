
const Info = () => {
    return (
        <div>
            <h1>Weather applicacion</h1>
            <p>Your city weather</p>
        </div>
    );
};

export default Info;